<?php
include "header.php";
?>
<h2>Semangat nginput <?=$_SESSION['nama']?>  !!</h2>
<?php
include "footer.php";
?>